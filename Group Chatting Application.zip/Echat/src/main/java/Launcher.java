import server.ServerLauncher;

public class Launcher {
    public static void main(String[] args) {
        ServerLauncher.main(new String[]{});
    }
}
