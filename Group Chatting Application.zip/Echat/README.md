# EChat
Chat App using Java Socket Programming

# Technologies

Mave

Client Server Architecture

# language
Java 11


multiple clients can join and chat in runtime..
